/*--------------------------------------------------------------------------------------------------------------------*/
/* �ɮצW�١GPdfGenerator.java                                                                                        */
/* �\�໡���G�N�Ϲ��ɮ��ഫ�� PDF ���C                                                                              */
/* ��s�ɶ��G2024/05/18                                                                                               */
/*--------------------------------------------------------------------------------------------------------------------*/
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
public class PdfGenerator{
    public PdfGenerator(String jpgFileName, String pdfFileName){
        // jpgFileName: �]�t������|�� jpg �ɮצW��
        // pdfFileName: �]�t������|�� pdf �ɮצW��
        // �ͦ��� pdf �ɮ׻P�� jpg �ɮץi���󤣦P�ؿ���
        try {
            convertImageToPDF(jpgFileName, pdfFileName);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    public PdfGenerator(String dirName, String jpgFileName, String pdfFileName){
        // jpgFileName: ���t���|�� jpg �ɮצW��
        // pdfFileName: ���t���|�� pdf �ɮצW��
        // �ͦ��� pdf �ɮ׻P�� jpg �ɮױN�P�ɦ�� dirName �ؿ���
        try {
            String theJpgFile=dirName+"\\"+jpgFileName;
            String thePdfFile=dirName+"\\"+pdfFileName;
            convertImageToPDF(theJpgFile, thePdfFile);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    public static void convertImageToPDF(String jpgFileName, String pdfFileName) throws IOException {
        try(PDDocument document=new PDDocument()){
            BufferedImage bufferedImage=ImageIO.read(new File(jpgFileName));
            int image_height=bufferedImage.getHeight();
            int image_width=bufferedImage.getWidth();
            PDRectangle customSize=new PDRectangle(image_width, image_height);  // �]�wPDF�j�p
            PDPage page=new PDPage(customSize);  // �ЫؾA�X�j�p�� PDF
            document.addPage(page);  // �л\�Ϥ��� PDF
            try(PDPageContentStream contentStream=new PDPageContentStream(document, page)){
                PDImageXObject pdImage=LosslessFactory.createFromImage(document, bufferedImage);
                contentStream.drawImage(pdImage, 0, 0);
            }
            document.save(pdfFileName);  // �O�s PDF
        }
    }
}