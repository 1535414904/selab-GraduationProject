import java.io.*;
import java.util.*;
import java.util.Calendar;
class TextFileWriter{
    File file;
    String theFileName;
    BufferedWriter writer;
    public TextFileWriter(String fileName){
        theFileName=fileName;
        try{
            file=new File(theFileName);
            writer=new BufferedWriter(new FileWriter(theFileName, true));
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public void writeContext(String str){
        try{
            if((file.exists()&&file.isFile())||!file.exists()){
                writer.write(str, 0, str.length());
                writer.flush();
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public void closeStream(){
        try{
            writer.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
}