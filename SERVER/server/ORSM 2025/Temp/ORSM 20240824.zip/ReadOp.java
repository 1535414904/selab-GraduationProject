/*--------------------------------------------------------------------------------------------------------------------*/
/* �ɮצW�١GReadOp.java                                                                                              */
/* �\�໡���G                                                                                                         */
/* ��s�ɶ��G2024/01                                                                                                  */
/*--------------------------------------------------------------------------------------------------------------------*/
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ReadOp{
    int reg_time=0;
    int over_time=0;
    int connect_time=0;
    int start_time=0;
    int total_op=0;
    int priority_op=0;
    int over_op=0;
    int over_room=0;
    String title="";
    String AllRooms="";
    String EachRoom="";
    String AllRoomsDirectory="";
    String AllRoomsfileName="";
    String EachRoomDirectory="";
    String EachRoomfileName="";
    public ReadOp(ArrayList<ArrayList<String>> line, String sf){
        File file=new File(sf);
        try(InputStreamReader isr=new InputStreamReader(new FileInputStream(file), "Big5")){
            BufferedReader in=new BufferedReader(isr);
            String temp="";
            temp=in.readLine();
            for (int i=0;i<6;i++){
                String apart[]=temp.split(",");
                if(i<2){
                    if(i==0){
                        AllRooms=apart[0];
                        Path path1=Paths.get(AllRooms);
                        AllRoomsDirectory=path1.getParent().toString();
                        AllRoomsfileName=path1.getFileName().toString();
                        createDirectoryIfNotExists(AllRoomsDirectory);
                    }else if(i==1){
                        EachRoom=apart[0];
                        Path path2=Paths.get(EachRoom);
                        EachRoomDirectory=path2.getParent().toString();
                        EachRoomfileName=path2.getFileName().toString();
                        createDirectoryIfNotExists(EachRoomDirectory);
                    }
                }else{
                    int extractedNumber=Integer.parseInt(apart[0]);
                    if(i==2){
                        start_time=extractedNumber;
                    }else if(i==3){
                        reg_time=extractedNumber;
                    }else if(i==4){
                        over_time=extractedNumber;
                    }else if(i==5){
                        connect_time=extractedNumber;
                    }
                }

                temp=in.readLine();
            }
            temp=in.readLine();
            title=temp;

            while((temp=in.readLine())!= null){  // �ۼ��D����
                if(temp.trim().isEmpty()){
                    break;
                }
                String apart[]=temp.split(",");
                ArrayList<String> inline=new ArrayList<>();
                for (int i=0;i<apart.length;i++){
                    inline.add(apart[i]);
                }

                line.add(inline);
            }

            int loop1=0;
            while((temp=in.readLine())!=null){
                Pattern pattern=Pattern.compile("\\d+");
                Matcher matcher=pattern.matcher(temp);
                int extractedNumber=0;
                while(matcher.find()){
                    extractedNumber=Integer.parseInt(matcher.group());
                    break;
                }
                if (loop1==0){
                    total_op=extractedNumber;
                }else if(loop1==1){
                    priority_op=extractedNumber;
                }else if(loop1==2){
                    over_op=extractedNumber;
                }else if(loop1==3){
                    over_room=extractedNumber;
                }
                loop1++;
            }
            in.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    private static void createDirectoryIfNotExists(String path){
        Path directoryPath=Paths.get(path);
        if (!Files.exists(directoryPath)){
            try{
                Files.createDirectories(directoryPath);
                System.out.println("�w�Ыظ��|�G" + path);
            } catch (IOException e){
                e.printStackTrace();
            }
        }
    }
    public int getReg_time(){
        return reg_time;
    }
    public int getOver_time(){
        return over_time;
    }
    public int getConnect_time(){
        return connect_time;
    }
    public int getStart_time(){
        return start_time;
    }
    public int getTotal_op(){
        return total_op;
    }
    public int getPriority_op(){
        return priority_op;
    }
    public int getOver_op(){
        return over_op;
    }
    public int getOver_room(){
        return over_room;
    }
    public String getAllRoomsDirectory(){
        return AllRoomsDirectory;
    }
    public String getAllRoomsfileName(){
        return AllRoomsfileName;
    }
    public String getEachRoomDirectory(){
        return EachRoomDirectory;
    }
    public String getEachRoomfileName(){
        return EachRoomfileName;
    }
}
