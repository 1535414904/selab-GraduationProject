/*--------------------------------------------------------------------------------------------------------------------*/
/* �ɮצW�١GArgs4GUIConverter.java                                                                                   */
/* �\�໡���G�t�s Arguments4GUI.csv �g�ഫ�᪺���e�C                                                                  */
/* ��s�ɶ��G2024/01                                                                                                  */
/*--------------------------------------------------------------------------------------------------------------------*/
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Args4GUIConverter{
    int reg;
    int over;
    int start;
    int connect;
    String AllRoomsDirectory = "";
    String AllRoomsfileName = "";
    String EachRoomDirectory = "";
    String EachRoomfileName = "";
    public Args4GUIConverter(String csvForGUI, String csvFilePath) {
        ArrayList<ArrayList<String>> line = new ArrayList<>();
        ReadOp ro = new ReadOp(line, csvForGUI);
        Pattern pattern = Pattern.compile("([^\\(]+)\\((\\d+)_(\\d+~\\d+)_#\\d+\\)");    //�w�q���h���F���Ҧ��A�u���M��
        Pattern pattern2 = Pattern.compile("([^\\(]+)\\((\\d+)_(\\d+~\\d+)_\\)");    //�w�q���h���F���Ҧ��A�D�u���M��
        Matcher matcher;
        String time_apart = "~";
        reg = ro.getReg_time();
        over = ro.getOver_time() +reg;
        start = ro.getStart_time();
        connect = ro.getConnect_time();
        AllRoomsDirectory = ro.getAllRoomsDirectory();
        AllRoomsfileName = ro.getAllRoomsfileName();
        EachRoomDirectory = ro.getEachRoomDirectory();
        EachRoomfileName = ro.getEachRoomfileName();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFilePath))) {
        	//�}�l�g��
            writer.write(",��v�m�W,��N�W��,�{�b�ɶ�,�����ɶ�,���A\n");
            for (int i = 0; i < line.size(); i++) {
                if (line.get(i).size() == 2) {
                    String input = line.get(i).get(0);
                    int index = input.indexOf("(");
                    String result = (index != -1) ? input.substring(0, index).trim() : input.trim();
                    writer.write(result + "\n");
                    continue;
                } else {
                    String input = line.get(i).get(0);
                    int index = input.indexOf("(");
                    String result = (index != -1) ? input.substring(0, index).trim() : input.trim();
                    writer.write(result + "\n");
                    for (int j = 2; j < line.get(i).size(); j++) {
                        if (line.get(i).get(j).contains("#")) {
                        	//�Y�]�t#�h���u���M��
                            matcher = pattern.matcher(line.get(i).get(j));
                        } else {
                            matcher = pattern2.matcher(line.get(i).get(j));
                        }
                        String name = "";
                        String extractedNumber = "";
                        String extractedRange = "";
                        if (matcher.find()) {
                            name = matcher.group(1);
                            extractedNumber = matcher.group(2);
                            extractedRange = matcher.group(3);
                        }
                        String stringWithoutSpaces = name.replaceAll("\\s", "");    //�R���ťզr��
                        writer.write("��1��," + stringWithoutSpaces + "," + extractedNumber + ",");

                        String time[] = extractedRange.split(time_apart);
                        int time1 = Integer.parseInt(time[0]);
                        int time2 = Integer.parseInt(time[1]);
                        int state = 0; // 1�X��B2�W�ɡB3�Y���W�ɡB4��z�ɶ�
                        if (time2 <= reg) {
                        	//���W��
                            state = 1;
                        } else if (time2 > reg && time2 <= over) {
                        	//�W��
                            state = 2;
                        } else if (time2 > over) {
                        	//�Y���W��
                            state = 3;
                        }
                        int start_hours = (start + time1) / 60;
                        int start_minutes = (start + time1) % 60;
                        int end_hours = (start + time2) / 60;
                        int end_minutes = (start + time2) % 60;
                        //�ഫ�}�l�ε����ɶ��A�q������p�ɤ���
                        String start_minutes_string = String.valueOf(start_minutes);
                        String end_minutes_string = String.valueOf(end_minutes);
                        if (start_minutes <= 0) {
                            start_minutes_string += '0';
                            writer.write(start_hours + ":" + start_minutes_string + ",");
                            if (end_minutes == 0) {
                                end_minutes_string += '0';
                                writer.write(end_hours + ":" + end_minutes_string + "," + state + "\n");
                            } else {
                                writer.write(end_hours + ":" + end_minutes_string + "," + state + "\n");
                            }
                        } else {
                            writer.write(start_hours + ":" + start_minutes + ",");
                            if (end_minutes == 0) {
                                end_minutes_string += '0';
                                writer.write(end_hours + ":" + end_minutes_string + "," + state + "\n");
                            } else {
                                writer.write(end_hours + ":" + end_minutes_string + "," + state + "\n");
                            }
                        }
                        int connect_hour = end_hours;
                        int connect_minutes = end_minutes + connect;
                        int covert_minutes = connect_hour*60 + connect_minutes;
                        int end_hours2 = covert_minutes/60;
                        int end_minutes2 = covert_minutes%60;
                        String end_minutes2_string = String.valueOf(end_minutes2);
                        if (end_minutes2 == 0) {
                            end_minutes2_string += '0';
                            writer.write("��1��," + "null,��z�ɶ�," + end_hours + ":" + end_minutes_string + ","
                                    + end_hours2 + ":" + end_minutes2_string  + "," + "4" + "\n");
                        } else {
                            writer.write("��1��," + "null,��z�ɶ�," + end_hours + ":" + end_minutes_string + ","
                                    + end_hours2 + ":" + end_minutes2 + "," + "4" + "\n");
                        }

                    }
                }
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public int getStartTime(){
        return start;
    }
    public String getAllRoomsDirectory(){
        return AllRoomsDirectory;
    }
    public String getAllRoomsfileName(){
        return AllRoomsfileName;
    }
    public String getEachRoomDirectory(){
        return EachRoomDirectory;
    }
    public String getEachRoomfileName(){
        return EachRoomfileName;
    }
}