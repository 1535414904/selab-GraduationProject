/*--------------------------------------------------------------------------------------------------------------------*/
/* �ɮצW�١GGanttChartGenerator.java                                                                                 */
/* �\�໡���G���X�̯S�ϡC                                                                                           */
/* ��s�ɶ��G2024/01                                                                                                  */
/*--------------------------------------------------------------------------------------------------------------------*/
import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListSelectionModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableModel;
public class GanttChartGenerator extends JFrame{
    private static final long serialVersionUID=1L;    
    private ArrayList<ArrayList<String>> Data=new ArrayList<ArrayList<String>>();
    private String path=System.getProperty("user.dir");    
    public GanttChartGenerator(String ScheduleCSV, int start_time, String dirImages){
        super("Gantt");
        GanttReader ganttread=new GanttReader(ScheduleCSV);
        Font boldFont=new Font("�L�n������", Font.BOLD, 13);
        UIManager.put("Button.font", new FontUIResource(boldFont));
        for(ArrayList<String> innerList : ganttread.getArray()){
            ArrayList<String> copiedInnerList=new ArrayList<>(innerList);
            Data.add(copiedInnerList);
        }
        JTabbedPane tabbedPane=new JTabbedPane();
        int Allday=0;
        int day=0;
        String apart=",";
        for(int i=0;i<Data.size();i++){ //���o�Ҧ��Ѽ�
            for(int j=0;j<Data.get(i).size();j++){
                String str[]=Data.get(i).get(j).trim().split(apart);
                String pattern="^��(\\d+)��$";
                Pattern r=Pattern.compile(pattern);
                Matcher m1=r.matcher(str[0]);
                if(m1.find()){
                    day=Integer.parseInt(m1.group(1));
                    if(day>Allday){
                        Allday=day;
                    }
                }else {        
                    continue;
                }
            }
        }        
        JScrollPane[][] jsp=new JScrollPane[Allday][1];  // [Day][Room]
        JLabel[][] jl=new JLabel[Allday][Data.size()];
        JButton[][] jbo=new JButton[Allday][Data.size()];
        JButton[][] jbc=new JButton[Allday][Data.size()];
        JButton[] opb=new JButton[Allday];
        JButton[] clb=new JButton[Allday];
        JPanel[][] jbpo=new JPanel[Allday][Data.size()];
        JPanel[][] jbpc=new JPanel[Allday][Data.size()];
        JPanel[][] jbt=new JPanel[Allday][Data.size()];
        JPanel[][] cjp=new JPanel[Allday][Data.size()];
        JPanel[] op=new JPanel[Allday];
        JPanel[] opbp=new JPanel[Allday];
        JSplitPane[][] split=new JSplitPane[Allday][Data.size()];
        for(int i=0;i<Allday;i++){
            for(int j=0;j<Data.size();j++){
                split[i][j]=new JSplitPane(JSplitPane.VERTICAL_SPLIT, null, null);
                split[i][j].setBorder(BorderFactory.createEmptyBorder());
                split[i][j].setContinuousLayout(true);
            }
        }
        String apart2=",";
        String picn="";
        for(int i=0;i<Allday;i++){//�Ѽ�
            int j=0;
            for(j=0;j<Data.size();j++){//�@�Ѧ��X�Ӥ�N��
                GanttDrawer dg=new GanttDrawer(Data.get(j), i+1, Data.size(), start_time);//�ھڸ��ø�s�̯S��
                int i2=i;
                int j2=j;
                class MyMouseListener extends MouseAdapter{    //�I��Jsplitpane�H�]�mbar��m
                    int clickCount=0;
                    public void mouseClicked(MouseEvent e){
                        clickCount++;
                        if(split[i2][j2].getDividerLocation()==300){
                            split[i2][j2].setDividerLocation(80);
                        }else {
                            split[i2][j2].setDividerLocation(300);
                        }
                   }
                }
                class Open implements ActionListener{
                    @Override
                    public void actionPerformed(ActionEvent e){
                        // TODO Auto-generated method stub
                        split[i2][j2].setDividerLocation(300);
                    }
                }
                class Close implements ActionListener {
                    @Override
                    public void actionPerformed(ActionEvent e){
                        // TODO Auto-generated method stub
                        split[i2][j2].setDividerLocation(80);
                    }
                }
                Open open=new Open();
                Close close=new Close();
                jl[i][j]=new JLabel(Data.get(j).get(0), SwingConstants.CENTER);
                picn=Data.get(j).get(0);
                Pattern pattern_room_number=Pattern.compile("\\d+");
                Pattern pattern_room_name=Pattern.compile("[A-Za-z]+");
                Matcher matcher_room_number=pattern_room_number.matcher(picn);
                Matcher matcher_room_name=pattern_room_name.matcher(picn);
                String n0 ="";
                String[] result=new String[picn.length()];
                if(matcher_room_name.find()){
                    result[0]=matcher_room_name.group();
                }
                if(matcher_room_number.find()){
                    int m1=Integer.parseInt(matcher_room_number.group());                
                    if(m1<10){
                        String m2=Integer.toString(m1);    
                        n0="0"+m2;
                        result[1]=n0;
                    }else{
                        n0=matcher_room_number.group();
                        result[1]=n0;
                    }
                }
                picn="";
                for(int k=0;k<result.length;k++){
                    if(result[k]==null)
                        break;
                    picn=picn+result[k];
                }
                jbo[i][j]=new JButton("�i�}");
                jbc[i][j]=new JButton("���_");
                jbo[i][j].addActionListener(open);
                jbc[i][j].addActionListener(close);
                jbo[i][j].setPreferredSize(new Dimension(60,30));
                jbc[i][j].setPreferredSize(new Dimension(60,30));
                split[i][j].addMouseListener(new MyMouseListener());                
                jbpo[i][j]=new JPanel();
                jbpo[i][j].setPreferredSize(new Dimension(70,60));
                jbpc[i][j]=new JPanel();
                jbpc[i][j].setPreferredSize(new Dimension(70,60));
                jbt[i][j]=new JPanel();                
                jbt[i][j].setLayout(new BorderLayout());
                JPanel space=new JPanel();
                jbpo[i][j].add(jbo[i][j],BorderLayout.CENTER);
                jbpc[i][j].add(jbc[i][j],BorderLayout.CENTER);
                jbt[i][j].add(jl[i][j],BorderLayout.NORTH);
                jbt[i][j].add(jbpo[i][j],BorderLayout.WEST);
                jbt[i][j].add(jbpc[i][j],BorderLayout.EAST);            
                cjp[i][j]=new JPanel();
                cjp[i][j].setLayout(new BorderLayout());
                dg.setSize(1000, 500);
                cjp[i][j].add(dg,BorderLayout.CENTER);
                BufferedImage myImage=new BufferedImage(dg.getWidth(), dg.getHeight(), BufferedImage.TYPE_INT_RGB);
                dg.paint(myImage.getGraphics());
                try {
                    File outputImage=new File(dirImages+"\\"+"��"+(i+1)+"��"+picn+".jpg");
                    ImageIO.write(myImage, "jpg", outputImage);
                    for(int i1=0;i1<split.length;i1++){
                        for(int j1=0;j1<split[i1].length;j1++){
                            split[i1][j1].setDividerLocation(80);
                        }
                    }
                    // System.out.println("��"+(i+1)+"��"+picn+".jpg "+"saved successfully.");
                }catch(IOException e){
                    e.printStackTrace();
                    System.out.println("Error");
                }
            }
            int k=0;
            for(k=0;k<(Data.size());k++){
                if((k+1)==(Data.size()-1)){//�N���w�g��̫�@��
                    split[i][k].add(cjp[i][k]);
                    split[i][k+1].setTopComponent(cjp[i][k+1]);
                    split[i][k+1].setBottomComponent(new JPanel());//.setBottomComponent();
                    split[i][k].add(split[i][k+1]);
                    break;                    
                }else{    
                    split[i][k].add(cjp[i][k]);
                    split[i][k].add(split[i][k+1]);
                }
            }
            jsp[i][0]=new JScrollPane(split[i][0]);
            jsp[i][0].setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            jsp[i][0].setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            jsp[i][0].getVerticalScrollBar().setUnitIncrement(20);
            jsp[i][0].setSize(new Dimension(20,20));
            int k0=i;
            class PerformeOP{
                public void someMethod(){
                    for(int k=0;k<split[k0].length;k++){
                        split[k0][k].setDividerLocation(300);
                    }
                }
            }
            class OpenAll implements ActionListener{
                @Override
                public void actionPerformed(ActionEvent e){
                    // TODO Auto-generated method stub
                    for(int k=0;k<split[k0].length;k++){
                        split[k0][k].setDividerLocation(300);
                    }    
                }
            }
            class PerformeCL{
                public void someMethod(){
                    for(int k=0;k<split[k0].length;k++){
                        split[k0][k].setDividerLocation(80);
                    }
                }
            }
            class CloseAll implements ActionListener{
                @Override
                public void actionPerformed(ActionEvent e){
                    // TODO Auto-generated method stub
                    PerformeCL performecl=new PerformeCL();
                    performecl.someMethod();
                }
            }
            OpenAll openall=new OpenAll();
            CloseAll closeall=new CloseAll();
            op[i]=new JPanel();
            op[i].setLayout(new BorderLayout());
            opbp[i]=new JPanel();
            opb[i]=new JButton("+");
            clb[i]=new JButton("-");
            opb[i].setPreferredSize(new Dimension(45,45));
            clb[i].setPreferredSize(new Dimension(45,45));
            opb[i].addActionListener(openall);
            clb[i].addActionListener(closeall);
            opbp[i].add(opb[i]);
            opbp[i].add(clb[i]);
            op[i].add(opbp[i],BorderLayout.WEST);
            op[i].add(jsp[i][0],BorderLayout.CENTER);
            tabbedPane.addTab("Day " +(i+1), op[i]);
        }    
        this.setContentPane(tabbedPane);
        this.validate();
        this.repaint();
    }
}