/*--------------------------------------------------------------------------------------------------------------------*/
/* �ɮצW�١GGanttDrawer.java                                                                                 */
/* �\�໡���Gø�s�̯S�ϡC                                                                                           */
/* ��s�ɶ��G2024/01                                                                                                  */
/*--------------------------------------------------------------------------------------------------------------------*/
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.font.TextAttribute;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;
import java.util.ArrayList;
import javax.swing.JPanel;
public class GanttDrawer extends JPanel{
    private static final long serialVersionUID=1L;
    private double zoomFactor=1.0;
    private int TASK_HEIGHT=25;
    private int START_TIME=0;
    private int END_TIME=24;
    private int time[][];
    private String timeStr[];
    private String[] opname;
    private String[] doctor;
    private String[] state;
    private ArrayList<String> backuplist=new ArrayList<String>();
    private Font font;
    private int amountroom=0;
    private String roomname="";
    private String roomday="";
    private int regStart_time=0;
    public GanttDrawer(ArrayList<String> Data1, int daynumber, int Allroom, int start_time){
        font=new Font("Microsoft JhengHei", Font.PLAIN, 13);
        regStart_time=(540-start_time)/2;
        roomday="��"+daynumber+"��";
        roomname=Data1.get(0);
        String apart=",";
        amountroom=Allroom;
        for(int i=1;i<Data1.size();i++){
            String str[]=Data1.get(i).trim().split(apart);
            int day=Integer.parseInt(str[0].replaceAll("[^\\d]", ""));
            if(day==daynumber){
                backuplist.add(Data1.get(i));
            }
        }
        time=new int[backuplist.size()][2];
        timeStr=new String[backuplist.size()];
        opname=new String[backuplist.size()];
        doctor=new String[backuplist.size()];
        state=new String[backuplist.size()];
        for(int i=0;i<backuplist.size();i++){
            String str[]=backuplist.get(i).trim().split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
            timeStr[i]=str[3]+" ~ "+str[4];
            String str1[]=str[3].trim().split(":");
            String str2[]=str[4].trim().split(":");
            int start=Integer.parseInt(str1[0])*60+Integer.parseInt(str1[1]);
            int end=Integer.parseInt(str2[0])*60+Integer.parseInt(str2[1]);
            time[i][0]=start;
            time[i][1]=end;
            opname[i]=str[2];
            doctor[i]=str[1];
            state[i]=str[5];
        }
    }
    @Override
    public void paint(Graphics g){
        super.paintComponents(g);
        setPreferredSize(new Dimension(900, amountroom * 150));
        setLayout(new GridBagLayout());
        Graphics2D g2=(Graphics2D) g;
        g2.setFont(font);
        g2.setColor(new Color(238, 238, 238));
        g2.fillRect(0, 0, super.getWidth(), super.getHeight());
        AttributedString attrroomday=new AttributedString(roomday);
        attrroomday.addAttribute(TextAttribute.FONT, font);
        attrroomday.addAttribute(TextAttribute.FOREGROUND, Color.BLACK);
        AttributedCharacterIterator iteratorday=attrroomday.getIterator();
        g2.drawString(iteratorday, 30, 20);
        AttributedString attrroomname=new AttributedString(roomname);
        attrroomname.addAttribute(TextAttribute.FONT, font);
        attrroomname.addAttribute(TextAttribute.FOREGROUND, Color.BLACK);
        AttributedCharacterIterator iteratorname=attrroomname.getIterator();
        g2.drawString(iteratorname, 35, 50);
        int a=100;
        int a2=12;
        int chartWidth=(int) (getWidth() * zoomFactor) - a;
        g2.setColor(Color.BLACK);
        g2.drawLine(a, a2+1, 720+a, a2+1);
        int k=0;
        int base=1;
        int pow=30;
        int time_length=24;
        for(int i=START_TIME;i<=time_length*pow;i++){
            if((i%pow)==0){
                if(k<10){
                    g2.drawString(Integer.toString(k), a+i-3, 11);
                } else {
                    g2.drawString(Integer.toString(k), a+i-7, 11);
                }
                g2.drawLine(a+i, a2+1, a+i, 2*a2+1);
                k++;
            }else if(i%(pow/6)==0){
                g2.drawLine(a+i, a2+6, a+i, a2+1);
            }
        }
        int y1=40;
        g2.setColor(Color.BLUE);
        g2.drawLine(a, y1+TASK_HEIGHT+10, 720+a, y1+TASK_HEIGHT+10);
        g2.drawLine(a, y1+TASK_HEIGHT+15, 720+a, y1+TASK_HEIGHT+15);
        for(int i=0;i<time.length;i++){
            int backup_i=i;
            int x11=a+time[i][0]/2-START_TIME;
            int x22=a+time[i][1]/2-START_TIME;
            if(time[i][1]>=1440){
                x22=a+1440/2-START_TIME;
                if(i!=(time.length-1)){
                    AttributedString attributedString1=new AttributedString("...�H�U�ٲ�");
                    Font newFont1=new Font("Microsoft JhengHei", Font.ITALIC, 15);
                    attributedString1.addAttribute(TextAttribute.FONT, newFont1);
                    attributedString1.addAttribute(TextAttribute.FOREGROUND, Color.RED);
                    AttributedCharacterIterator iterator1=attributedString1.getIterator();
                    g2.drawString(iterator1, 840, 60);
                }
            }
            if(state[i].equals("1")){
                g2.setColor(Color.GREEN);
            } else if(state[i].equals("2")){
                g2.setColor(Color.YELLOW);
            } else if(state[i].equals("3")){
                g2.setColor(Color.RED);
            } else {
                g2.setColor(Color.BLUE);
            }
            g2.fillRect(x11, y1, x22-x11, TASK_HEIGHT);
            g2.setColor(Color.BLACK);
            g2.drawRect(x11, y1, x22-x11, TASK_HEIGHT);

            int x1=a+time[i][0]/2-START_TIME;
            int x2=a+time[i][1]/2-START_TIME;
            if(time[i][1]>1440){
                x2=a+1440/2-START_TIME;
            }
            int y=a+i*TASK_HEIGHT+50;
            if(state[i].equals("1")){
                g2.setColor(Color.GREEN);
            } else if(state[i].equals("2")){
                g2.setColor(Color.YELLOW);
            } else if(state[i].equals("3")){
                g2.setColor(Color.RED);
            } else {
                g2.setColor(Color.BLUE);
            }

            g2.fillRect(x1, y, x2-x1, TASK_HEIGHT);
            g2.setColor(Color.BLACK);
            g2.drawRect(x1, y, x2-x1, TASK_HEIGHT);

            String doctor1=doctor[i] + " ,";
            AttributedString attributedString0=new AttributedString(doctor1);
            AttributedString attributedString=new AttributedString(opname[backup_i]);
            Font newFont=new Font("Microsoft JhengHei", Font.ITALIC, 15);
            attributedString0.addAttribute(TextAttribute.FONT, newFont);
            attributedString0.addAttribute(TextAttribute.FOREGROUND, Color.BLACK);
            AttributedCharacterIterator iterator0=attributedString0.getIterator();
            attributedString.addAttribute(TextAttribute.FONT, newFont);
            attributedString.addAttribute(TextAttribute.FOREGROUND, Color.BLACK);
            AttributedCharacterIterator iterator=attributedString.getIterator();
            FontMetrics metrics=g2.getFontMetrics(font);
            int strWidth=metrics.stringWidth(opname[backup_i]);
            int strWidth0=metrics.stringWidth(doctor1);
            AttributedString attributedString1=new AttributedString(timeStr[i]);
            Font newFont1=new Font("Microsoft JhengHei", Font.ITALIC, 15);
            attributedString1.addAttribute(TextAttribute.FONT, newFont1);
            attributedString1.addAttribute(TextAttribute.FOREGROUND, Color.BLACK);
            AttributedCharacterIterator iterator1=attributedString1.getIterator();
            g2.drawString(iterator0, x1-strWidth0-strWidth-60, y+TASK_HEIGHT-5);
            g2.drawString(iterator, x1-strWidth-40, y+TASK_HEIGHT-5);
            g2.drawString(iterator1, x2+10, y+TASK_HEIGHT-8);
            if(time[i][1]>=1440){
                break;
            }
        }
    }
}