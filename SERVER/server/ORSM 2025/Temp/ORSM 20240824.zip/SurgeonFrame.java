/*ø�Ϫ��ج[*/
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

public class SurgeonFrame extends JFrame{
	
	private DrawSurgeon ds;
	private DrawSurgeonNotExposed dsne;
	private CalculateFrameLength clf;
	private int FrameLength = 0;
	private String PictureDirectory = "";
	private ArrayList<Integer> ApartIndex = new ArrayList<Integer>();
	
	public SurgeonFrame(ArrayList<ArrayList<ArrayList<String>>> ReorderSurgeonList, String Directory, String PdfTitle) {

		PictureDirectory = Directory;
		clf = new CalculateFrameLength(ReorderSurgeonList);
		FrameLength = clf.getFrameLength();    //���o�Ϥ��ݭn���`����
		ApartIndex = clf.getApartIndex();    //���o������Index�ݭn���M
		ds = new DrawSurgeon(ReorderSurgeonList, FrameLength, ApartIndex, PdfTitle);    //�}�lø�ϡAString PdfTitle���Ϥ��W�誺���D
		ds.setSize(1200, FrameLength+100);    //�]�w�Ϥ��j�p
		this.add(ds);
		this.setSize(1200, FrameLength+100);
//		this.setVisible(true);
//		this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
		this.SavePic();

	}
	
	public SurgeonFrame(ArrayList<ArrayList<ArrayList<String>>> ReorderSurgeonList,String msg1,String msg2, String Directory, String PdfTitle) {

		PictureDirectory = Directory;
		clf = new CalculateFrameLength(ReorderSurgeonList);
		FrameLength = clf.getFrameLength();    //���o�Ϥ��ݭn���`����
		ApartIndex = clf.getApartIndex();    //���o������Index�ݭn���M
		dsne = new DrawSurgeonNotExposed(ReorderSurgeonList, msg1, msg2, FrameLength, PdfTitle);    //�}�lø�ϡAString PdfTitle���Ϥ��W�誺���D		
		dsne.setSize(1200,FrameLength+100);    //�]�w�Ϥ��j�p
		this.add(dsne);
		this.setSize(1200, FrameLength+100);
//		this.setVisible(true);
//		this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
		this.SavePicNotExposed();

	}
	
	public void SavePic() {
		//�O�s�Ϥ�(���S)
		File outputImage = new File(PictureDirectory+"\\"+"Output"+".jpg");
		BufferedImage myImage =  new BufferedImage(1200, FrameLength +100, BufferedImage.TYPE_INT_RGB);
		ds.paint(myImage.getGraphics());
		try {
			ImageIO.write(myImage, "jpg", outputImage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("���S ");
		PdfGenerator WriteOutput = new PdfGenerator(PictureDirectory,"Output.jpg","Output.pdf");    //�x�s��PDF��
	}
	
	public void SavePicNotExposed() {
		//�O�s�Ϥ�(�����S)
		File outputImage = new File(PictureDirectory+"\\"+"Output"+".jpg");
		BufferedImage myImage =  new BufferedImage(1200, FrameLength +100, BufferedImage.TYPE_INT_RGB);
		dsne.paint(myImage.getGraphics());
		try {
			ImageIO.write(myImage, "jpg", outputImage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("�����S ");
		PdfGenerator WriteOutput = new PdfGenerator(PictureDirectory,"Output.jpg","Output.pdf");    //�x�s��PDF��
	}
}
