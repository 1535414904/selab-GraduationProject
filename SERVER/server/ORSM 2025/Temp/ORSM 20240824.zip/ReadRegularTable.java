/*Ū��RegularTable.csv*/
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class ReadRegularTable {

	private ArrayList<ArrayList<String>> twoDList = new ArrayList<ArrayList<String>>();    //�x�s��ƪ��G��ArrayList

	
	public ReadRegularTable(String Regular) {
		
		try(InputStreamReader isr = new InputStreamReader(new FileInputStream(Regular),"Big5")){    //Ū�ɨó]�wcsv�ɬ�Big5�s�X
			BufferedReader in = new BufferedReader(isr);
			String temp = "";
			String apart = ",";
			
			while((temp = in.readLine())!=null) {
				
				String first[] = temp.split(apart);
				ArrayList<String> Surgery = new ArrayList<String>();
				for(int i=0;i<first.length;i++) {
					Surgery.add(first[i]);
					//�� "," ���αNŪ�ɤ�r�@�@�s�J�@��ArrayList Surgery
				}				
				twoDList.add(Surgery);
//				Surgery.clear();
			}
			isr.close();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		for(int i=0;i<twoDList.size();i++) {
//			System.out.println(twoDList.get(i));
//		}
	}	
	
	public ArrayList<ArrayList<String>> getArrayList(){
		return  twoDList;
		//�^��Ū�ɧ����G��ArrayList twoDList
	}
}
