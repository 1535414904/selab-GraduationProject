import java.io.*;
import java.util.*;
class TextFileReader{
    public boolean getContext(String fileName, Vector<String> context){
        BufferedReader reader;  String str;
        try{
            reader=new BufferedReader(new FileReader(fileName));
            while((str=reader.readLine())!=null){
                context.addElement(str);
            }
            reader.close();
        }catch(Exception e){
            return false;
        }
        return true;
    }
}