/*--------------------------------------------------------------------------------------------------------------------*/
/* �ɮצW�١GMergeGantt4AllRooms.java                                                                                 */
/* �\�໡���G��X��N�Ъ������Ϲ� (MergedImage.jpg)�C                                                                 */
/* ��s�ɶ��G2024/05/18                                                                                               */
/*--------------------------------------------------------------------------------------------------------------------*/
import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
public class MergeGantt4AllRooms{
    public MergeGantt4AllRooms(String sourceDirName, String destDirName){
        mergeAll(sourceDirName, destDirName, "Title");
        /*--- �H�U�� 2024/05/18 �e���������e ---*/ 
/*
        File folder=new File(sourceDirName);
        int day=0, room=0;
        if(folder.exists() && folder.isDirectory()){
            File[] files=folder.listFiles();
            if(files != null){
                BufferedImage combinedImage=new BufferedImage(1000, 100*files.length, BufferedImage.TYPE_INT_RGB);
                int combinedY=0;
                for(File file:files){
                    if(isImageFile(file)){
                        try {
                            BufferedImage image=ImageIO.read(file);
                            String fileName=file.getName();
                            day=extractDay(fileName);
                            int x=0;
                            int y=0;
                            int width=1000;
                            int height=100;
                            BufferedImage croppedImage=image.getSubimage(x, y, width, height);
                            combinedImage.getGraphics().drawImage(croppedImage, 0, combinedY, null);
                            combinedY += height;
                        } catch (IOException e){
                            e.printStackTrace();
                        }
                    }
                }
                try {
                    File outputfile=new File(destDirName+"\\"+"MergedImage.jpg");
                    ImageIO.write(combinedImage, "jpg", outputfile);
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("�L�Ī���󧨸��|�C");
        }
*/
    }
    public MergeGantt4AllRooms(String sourceDirName, String destDirName, String theTitle){
        mergeAll(sourceDirName, destDirName, theTitle);
    }
    private static void mergeAll(String sourceDirName, String destDirName, String theTitle){
        File folder=new File(sourceDirName);
        int day=0, room=0;
        if(folder.exists() && folder.isDirectory()){
            File[] files=folder.listFiles();  // �C�X�Ҧ��ɮ�
            if(files != null){
                int combinedY=80;  // ���D Y �b�_�l��m
                BufferedImage combinedImage=new BufferedImage(1000, 100*files.length+combinedY, BufferedImage.TYPE_INT_RGB);
                Graphics2D g2d = combinedImage.createGraphics();  // �Ы� 2D ø�Ͼ�
                g2d.setColor(new Color(238, 238, 238));  // �]�w�I���C��
                g2d.fillRect(0, 0, 1000, 500 * files.length);  // ��R�I��
        		Font newFont0 = new Font("Microsoft JhengHei", Font.PLAIN, 20);
        		g2d.setColor(Color.BLACK);
        		g2d.setFont(newFont0);  // �]�m�r��M�C��
                FontMetrics fontMetrics0 = g2d.getFontMetrics();
                int stringWidth0 = fontMetrics0.stringWidth(theTitle);
                int x0 = 1000/2 - stringWidth0/2;  // �]�w���D X �b�_�l��m
                g2d.drawString(theTitle, x0, 40);  // ø�s���D
                for(File file:files){
                    if(isImageFile(file)){  // �P�_�O�_������
                        try {
                            BufferedImage image=ImageIO.read(file);
                            String fileName=file.getName();
                            day=extractDay(fileName);
                            int x=0;
                            int y=0;
                            int width=1000;
                            int height=100;
                            BufferedImage croppedImage=image.getSubimage(x, y, width, height);  // �����O�d�Ϥ��W�b��
                            // �N�@����N�йϤ��[�J�j�� BufferedImage
                            combinedImage.getGraphics().drawImage(croppedImage, 0, combinedY, null);
                            combinedY += height;
                        } catch (IOException e){
                            e.printStackTrace();
                        }
                    }
                }
                try {
                    File outputfile=new File(destDirName+"\\"+"MergedImage.jpg");
                    ImageIO.write(combinedImage, "jpg", outputfile);
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("�L�Ī���󧨸��|�C");
        }
    }
    private static boolean isImageFile(File file){
        String name=file.getName().toLowerCase();
        return name.endsWith(".jpg")||name.endsWith(".jpeg")||name.endsWith(".png");
    }
    private static int extractDay(String fileName){
        String[] parts=fileName.split("��");
        return Integer.parseInt(parts[0].substring(1));
    }
    private static int extractRoom(String fileName){
        String[] parts=fileName.split("��");
        return Integer.parseInt(parts[1].split("\\.")[0]);
    }
}
