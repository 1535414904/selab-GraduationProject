/*--------------------------------------------------------------------------------------------------------------------*/
/* �ɮצW�١GGanttReader.java                                                                                 */
/* �\�໡���GŪ���̯S�ϡC                                                                                           */
/* ��s�ɶ��G2024/01                                                                                                  */
/*--------------------------------------------------------------------------------------------------------------------*/
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
public class GanttReader{
    private ArrayList<ArrayList<String>> twoDList=new ArrayList<ArrayList<String>>();
    private ArrayList<Integer> roomindex=new ArrayList<Integer>();
    private ArrayList<String> room=new ArrayList<String>();
    public GanttReader(String sf){
        int roomnum=0;
        boolean croom=false;
        try(BufferedReader in=new BufferedReader(new FileReader(sf))){
            String temp="";
            String apart=",";
            temp=in.readLine();
            while((temp=in.readLine())!=null){
                while(temp.equals("")){
                    temp=in.readLine();
                }
                room.add(temp);
                if(!(temp.contains(","))){
                    roomindex.add(roomnum);
                }
                roomnum++;
            }
            for(int i=0;i<roomindex.size();i++){
                int index=roomindex.get(i);
                int index2;
                if(i+1>roomindex.size()){
                    break;
                }else{
                    int i2=i+1;
                    if(i2==roomindex.size()){
                        index2=room.size();
                        ArrayList<String> rr=new ArrayList<String>();
                        for(int j=index;j<index2;j++){
                            rr.add(room.get(j));
                        }
                        twoDList.add(rr);
                    }else if(i2<roomindex.size()){
                        index2=roomindex.get(i2);
                        ArrayList<String> rr=new ArrayList<String>();
                        for (int j=index;j<index2;j++) {
                            rr.add(room.get(j));
                        }
                        twoDList.add(rr);
                    }
                }
            }
            String first[]=twoDList.get(1).get(1).trim().split(apart);
            String apart2=":";
            String first1[]=first[4].trim().split(apart2);
            int day=Integer.parseInt(first1[0]);
            in.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public ArrayList<ArrayList<String>> getArray(){
        return twoDList;
    }
}